package pri.tool.bean;

public class FrameRate {
    public int numerator;
    public int denominator;

    FrameRate(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }
}
