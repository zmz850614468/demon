# AnV4L2Camera
Android 通过V4L2接口调用camera

因为需要能够打开设备 "/dev/video0" 可能在手机或其他成品机器上没有权限运行
