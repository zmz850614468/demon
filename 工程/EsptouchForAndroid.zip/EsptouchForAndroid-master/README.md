# EspTouch for Android
This APP is used to configure ESP devices to connect target AP, the devices need run smart config.

## Licence
- See [Licence](ESPRESSIF_MIT_LICENSE_V1.LICENSE)

## Version Log
- See [Log](Log.md)

## Jar Release
- See [libs](releases/libs)  
    - If you don't want use [esptouch](esptouch) module, copy the jar to your own project.