package com.espressif.iot.esptouch.demo_activity.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.espressif.iot.esptouch.demo_activity.BaseActivity;
import com.espressif.iot.esptouch.demo_activity.MyApplication;
import com.espressif.iot_esptouch_demo.R;

import java.util.HashMap;
import java.util.Map;

public class LoginSSActivity extends BaseActivity {

    EditText e1, e2, e3, e4, e5;
    TextView t1, t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_ss);


        initView();
    }

    private void initView() {

        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        e3 = findViewById(R.id.e3);
        e4 = findViewById(R.id.e4);
        e5 = findViewById(R.id.e5);
        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);

        findViewById(R.id.b1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Map<String, String> map = new HashMap<>();
                map.put("phone", e1.getText().toString());

                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/sendMsg", map, 1);

                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/sendMsg" + "\n"+"phone="+e1.getText().toString());

            }
        });
        findViewById(R.id.b2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Map<String, String> map = new HashMap<>();
                map.put("phone", e1.getText().toString());
                map.put("yzm", e2.getText().toString());
                map.put("password", e3.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/userLogin", map, 2);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/sendMsg"
                        + "\n"+"phone="+e1.getText().toString()
                        + "\n"+"yzm="+e2.getText().toString()
                        + "\n"+"password="+e3.getText().toString());
            }
        });
        findViewById(R.id.b3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Map<String, String> map = new HashMap<>();
                map.put("phone", e1.getText().toString());
                map.put("yzm", e2.getText().toString());
                map.put("password", e3.getText().toString());
                map.put("lat", e5.getText().toString());
                map.put("lng", e4.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/userRegister", map, 3);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/sendMsg"
                        + "\n"+"phone="+e1.getText().toString()
                        + "\n"+"yzm="+e2.getText().toString()
                        + "\n"+"password="+e3.getText().toString()
                        + "\n"+"lat="+e4.getText().toString()
                        + "\n"+"lng="+e5.getText().toString());
            }
        });

        findViewById(R.id.b4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText("");
                t2.setText("");
            }
        });
    }


    @Override
    public void showSuccess(String result, int type) {
        super.showSuccess(result, type);
        t2.setText(result + "");
    }

}
