package com.espressif.iot.esptouch.demo_activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.Map;

public class BaseActivity extends FragmentActivity implements View.OnClickListener ,UrlModelImp{


    private ProgressDialog mProgressDialog;
    public SharedPreferencesUtil preferencesUtil ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setCancelable(true);
        mProgressDialog.setMessage("数据请求中");
        preferencesUtil  = new SharedPreferencesUtil(BaseActivity.this);
    }

    // 在BaseActivity 中重写
    @Override
    public Resources getResources() {
        Resources res = super.getResources();
        Configuration config = new Configuration();
        config.setToDefaults();
        res.updateConfiguration(config, res.getDisplayMetrics());
        return res;
    }

    public void GoActivity(Class clazz){
        startActivity(new Intent(this,clazz));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {

    }
    public void showLoading() {
        new Handler().post(new Runnable() {
            @Override
            public void run() {
                if (!mProgressDialog.isShowing()) {
                    mProgressDialog.show();
                }
            }
        });
//        ObtainProvince(true);
    }

    public void hideLoading() {
        new Handler().post(new Runnable() {
            @Override
            public void run() {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            }
        });
    }

    public void putpreferencesUtilString(String key, String value){
        if (preferencesUtil!=null){
            preferencesUtil.putString(ShareFile.USERFILE,key,value);
        }
    }
    public String getpreferencesUtilString(String key, String value){
        String is = "";
        if (preferencesUtil!=null){
            is = preferencesUtil.getString(ShareFile.USERFILE,key,value);
        }
        return is ;
    }

    public void showToast(String toastMsg) {
        Toast.makeText(this, toastMsg, Toast.LENGTH_SHORT).show();
    }


    public void HttpGet(String url, int type){
        Log.i("info","------------"+type);
        UrlModel.getInstance(BaseActivity.this).HttpGet(url,type, this);
    }

    public void HttpPost(String url, Map<String,String> map , int type){
        Log.i("info","------------"+type);
        UrlModel.getInstance(BaseActivity.this).HttpPost(url,map,type, this);
    }

    @Override
    public void showSuccess(String result, int type) {
//        hideLoading();
        Log.i("info","------------"+result);
    }

    @Override
    public void showError(String msg) {
        hideLoading();
        Log.i("showError","------------"+msg);
    }
}
