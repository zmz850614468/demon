package com.espressif.iot.esptouch.demo_activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.espressif.iot.esptouch.demo_activity.activity.DeviceDataShujuActivity;
import com.espressif.iot.esptouch.demo_activity.activity.HuoquNewPointActivity;
import com.espressif.iot.esptouch.demo_activity.activity.KongzhiDeviceActivity;
import com.espressif.iot.esptouch.demo_activity.activity.LoginSSActivity;
import com.espressif.iot.esptouch.demo_activity.activity.ShebeiZhuceActivity;
import com.espressif.iot.esptouch.demo_activity.activity.ShezhiUseridActivity;
import com.espressif.iot.esptouch.demo_activity.activity.ShezhiUseridActivity;
import com.espressif.iot_esptouch_demo.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends BaseActivity {


    private int chaxunLat = 0x11;
    private int chaxunUserDevice = 0x12;
    TextView t1 ,t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);

        findViewById(R.id.btn_001).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoActivity(EsptouchDemoActivity.class);
            }
        });

        findViewById(R.id.btn_0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             GoActivity(ShezhiUseridActivity.class);
            }
        });


        findViewById(R.id.btn_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoActivity(ShebeiZhuceActivity.class);
            }
        });

        findViewById(R.id.btn_2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String path = MyApplication.getInstance().getUrl() + "/api/revdata/getLatLng?userid="+getpreferencesUtilString(ShareFile.UID,"");
                HttpGet(path,chaxunLat);
                t1.setText(path);
            }
        });

        findViewById(R.id.btn_3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Map<String, String> map = new HashMap<>();
                map.put("userid", getpreferencesUtilString(ShareFile.UID,""));
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/queryUserDevices", map, chaxunUserDevice);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/queryUserDevices"
                        +"\n"+"userid="+getpreferencesUtilString(ShareFile.UID,""));
            }
        });

        //获取最新数据（数据库）
        findViewById(R.id.btn_4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoActivity(HuoquNewPointActivity.class);
            }
        });

        findViewById(R.id.btn_5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoActivity(DeviceDataShujuActivity.class);
            }
        });

        findViewById(R.id.kunzhi_device_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoActivity(KongzhiDeviceActivity.class);
            }
        });

        findViewById(R.id.delete_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText("");
                t2.setText("");
            }
        });

        findViewById(R.id.zhanghaozhuce_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoActivity(LoginSSActivity.class);

            }
        });

    }

    @Override
    public void showSuccess(String result, int type) {
        super.showSuccess(result, type);

        t2 .setText("result= "+result);

        if (type == chaxunLat){
            Log.i("info",""+result);

        }else if(type == chaxunUserDevice){
//            t1 .setText("查询经纬度 result= "+result);
            try {
                JSONObject json = new JSONObject(result);
                if (json.optString("flag").equals("00")){
                    JSONArray array = json.optJSONArray("userdevice");
                    if (array!=null&&array.length()>0){
                        JSONObject itemJson  = array.optJSONObject(0);
                        String deviceid = itemJson.optString("deviceid");
                        String devicename= itemJson.optString("devicename");
                        String devicetype= itemJson.optString("devicetype");
                        String time= itemJson.optString("time");
                        String image= itemJson.optString("image");
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }
}
