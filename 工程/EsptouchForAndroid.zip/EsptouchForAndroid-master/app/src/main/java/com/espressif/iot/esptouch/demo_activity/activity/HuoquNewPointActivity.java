package com.espressif.iot.esptouch.demo_activity.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.espressif.iot.esptouch.demo_activity.BaseActivity;
import com.espressif.iot.esptouch.demo_activity.MyApplication;
import com.espressif.iot.esptouch.demo_activity.NetUtil;
import com.espressif.iot.esptouch.demo_activity.ShareFile;
import com.espressif.iot_esptouch_demo.R;

import java.util.HashMap;
import java.util.Map;

public class HuoquNewPointActivity extends BaseActivity {

    EditText e1, e2, e3, e4;
    Button b1, b2;
    TextView t1,t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shebei_newpoint);

        e2 = findViewById(R.id.e2);
        e3 = findViewById(R.id.e3);

        t2 = findViewById(R.id.t2);
        b1 = findViewById(R.id.b1);
        t1 = findViewById(R.id.t1);
        b2 = findViewById(R.id.b2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Map<String, String> map = new HashMap<>();
                map.put("op", "" + e2.getText().toString());
                map.put("deviceid", "" + e3.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/getDataPoint", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/getDataPoint"
                        +"\n"+"op="+"" + e2.getText().toString()
                        +"\n"+"deviceid="+"" + e3.getText().toString());
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t1.setText("");
                t2.setText("");
            }
        });
    }

    @Override
    public void showSuccess(String result, int type) {
        super.showSuccess(result, type);
        if (type == 1) {
            t2.setText(result + "");
        }
    }
}
