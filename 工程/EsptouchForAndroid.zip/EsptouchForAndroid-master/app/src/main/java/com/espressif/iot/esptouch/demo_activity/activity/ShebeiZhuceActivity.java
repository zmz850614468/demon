package com.espressif.iot.esptouch.demo_activity.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.espressif.iot.esptouch.demo_activity.BaseActivity;
import com.espressif.iot.esptouch.demo_activity.MyApplication;
import com.espressif.iot.esptouch.demo_activity.NetUtil;
import com.espressif.iot_esptouch_demo.R;
import com.espressif.iot.esptouch.demo_activity.ShareFile;

public class ShebeiZhuceActivity extends BaseActivity {

    EditText e1 ,e2, e3, e4 ;
    Button b1,b2 ;
    TextView t1,t2 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shebei_zhuce);


        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        e3 = findViewById(R.id.e3);
        e4 = findViewById(R.id.e4);

        e1.setText(getpreferencesUtilString(ShareFile.UID,""));
        e2.setText(getpreferencesUtilString(ShareFile.DEVICEID3,""));

        b1 = findViewById(R.id.b1);
        t1 = findViewById(R.id.t1);
        b2 = findViewById(R.id.b2);
        t2 = findViewById(R.id.t2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String path = MyApplication.getInstance().getUrl() + "/api/revdata/register?userid="+e1.getText().toString()+
                        "&devid="+e2.getText().toString()+"&devflag="+e3.getText().toString()+"&devname="+e4.getText().toString();
                HttpGet(path,1);
                t1.setText(path+"");
            }
        });

        findViewById(R.id.b2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText("");
                t2.setText("");
            }
        });
    }
    @Override
    public void showSuccess(String result, int type) {
        super.showSuccess(result, type);
        if (type == 1){
            t2.setText(result+"");
        }
    }
}
