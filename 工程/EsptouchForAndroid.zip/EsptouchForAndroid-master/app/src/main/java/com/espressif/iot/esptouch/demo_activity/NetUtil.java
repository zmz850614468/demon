package com.espressif.iot.esptouch.demo_activity;

import java.util.HashMap;
import java.util.Map;

/**
 * 前缀
 * Created by Administrator on 2017/3/13.
 */

public class NetUtil {

//
//////    public static final String al_url_test = "http://193.112.204.220";
////
////    public static final String al_url_1 = "http://193.112.204.220:5858";
//////
////    public static final String al_url = al_url_1;
////
////    //211.149.216.60:6005
//    //193.112.204.220:6005
//    public static final String prePath = al_url+":6005/api/";
//
//    public static final String prePath_6005 = al_url+":6005/api/";
//    public static final String prePath_6006 = al_url+":6006/api/";
//    public static final String prePath_6007 = al_url+":6007/api/";
//
//
//
//    public static final String prePathUser = prePath_6005 + "user/";
//    public static final String prePathEngineer= al_url+":6007/api/Engineer/";
//    public static final String prePathUser6006 = prePath_6006 + "dtmanna/";
//
//
////    public static final String prePathTest = al_url_test + ":6006/api/dtmanna/";
////    public static final String prePathUserTest = al_url_test + ":6005/api/user/";
////    public static final String prePathEngineerTest = al_url_test + ":6007/api/Engineer/";
//
//
//    public static final String prePath_6007_Enginner = prePath_6007 + "Engineer/";
//    public static final String prePathUser6007 = prePath_6007 + "Engineer/";
//
//    //读取图片
//    public static final String prePath_img = al_url+":6005";
////    public static final String prePath_img = al_url_test+":6005";
//    public static final String IMAGE_URL = al_url+":6005";
//    public static final String SLIDESHOW_URL = al_url+":6005/";
//
//    private static String getMap(String urlMethod, Map<String, String> map) {
//        String url = prePathUser + urlMethod + "";
//        String str = "";
//        for (Map.Entry<String, String> entry : map.entrySet()) {
//            str += (str == "" ? "" : "&") + entry.getKey() + "=" + entry.getValue();
//        }
//        url += (str == "" ? "" : "?") + str;
//        return url;
//    }
//
//    public static String getMap(Map<String, String> map) {
//        String url = "";
//        String str = "";
//        for (Map.Entry<String, String> entry : map.entrySet()) {
//            str += (str == "" ? "" : "&") + entry.getKey() + "=" + entry.getValue();
//        }
//        url += (str == "" ? "" : "?") + str;
//        return url;
//    }
//
//
//    //    public static String Login(String mobile, String password){
////        Map<String, String > map = new HashMap<>();
////        map.put("mobile",mobile);
////        map.put("password",password);
////        return getMap("Login",map);
////    }
//    // 发送验证码 POST
//    public static String sendMsg() {
//        return prePathUser + "sendMsg";
//    }
//
//
//    // 注册 POST
//    public static String Register() {
//        return prePathUser + "register";
//    }
//
//    // 登陆 POST
//    public static String Login() {
//        return prePathUser + "login";
//    }
//
//    // 获取首页轮播图 GET
//    // http://211.149.216.60:6005/api/user/getUserImg?role=
//    public static String getUserImg(String string) {
//        Map<String, String> map = new HashMap<>();
//        map.put("role", string);
//        return getMap("getUserImg", map);
//    }
//
//    // 社区显示
//    //  192.168.1.101:55553/api/dtmanna/community
//    public static String community() {
//        return prePath_6005 + "/dtmanna/community";
//    }
//
//    // 首页banner
//    //http://193.112.204.220:6005/api/user/getUserImg?role=%E8%B6%85%E7%BA%A7%E7%AE%A1%E7%90%86%E5%91%98
//    public static String getUserImg() {
//        return prePathUser + "/getUserImg";
//    }
//
//    // 首页底部list
//    //http://193.112.204.220:6005/api/user/getBannerList?userid=1
//    public static String getBannerList() {
//        return prePathUser + "/getBannerList";
//    }
//
//    //Home服务顶部标题
//    public static String ServiceType() {
//        return prePathUser + "getServiceType";
//    }
//
//    //Home服务底部列表
//    //http://193.112.204.220:6005/api/user/getServerList?typeid=5&pageIndex=1&pagesize=10
//    public static String getServerList() {
//        return prePathUser + "getServerList";
//    }
//
//    //大话题详情
//    //http://193.112.204.220:6005/api/user/getDiscussList?comunityid=3&pageindex=1&pagesize=10&type=0&userid=2&discussname=%E4%BF%9D%E5%85%BB&userid=2
//    public static String getDiscussList() {
//        return prePathUser + "getDiscussList";
//    }
//
//    //小话题详情
//    //http://193.112.204.220:6005/api/user/getDiscussInfo?userid=1&discussId=1
//    public static String getDiscussInfo() {
//        return prePathUser + "getDiscussInfo";
//    }
//
//    //service服务列表
//    //http://193.112.204.220:6005/api/user/getEngineerList?PageIndex=1&pagesize=10&serviceType=项目工程
//    public static String getEngineerList() {
//        return prePathUser + "getEngineerList";
//    }
//
//    //service服务详情
//    //http://193.112.204.220:6005/api/user/getEngineerInfo?engineerId=1
//    public static String getEngineerInfo() {
//        return prePathUser + "getEngineerInfo";
//    }
//
//    //service 服务详情评论列表
//    //http://193.112.204.220:6005/api/user/getEngCommentList?engineerId=1&pageIndex=1&pageSize=10&replayType=0
//    public static String getEngCommentList() {
//        return prePathUser + "getEngCommentList";
//    }
//
//    //添加订单消息
//    //http://193.112.204.220:6006/api/dtmanna/usFeedback
//    public static String saveSystem()
//    {
//        return prePathUser + "saveSystem";
//    }
//
//    //address 列表
//    //http://193.112.204.220:6005/api/user/getAddressList?userId=1&userType=0
//    public static String getAddressList() {
//        return prePathUser + "getAddressList";
//    }
//
//    //address 保存地址
//    //http://193.112.204.220:6005/api/user/addorupdateAddress
//    public static String addorupdateAddress() {
//        return prePathUser + "addorupdateAddress";
//    }
//
//    //address 删除地址
//    //http://193.112.204.220:6005/api/user/deleteAddresss
//    public static String deleteAddresss() {
//        return prePathUser + "deleteAddress";
//    }
//
//    // 发布订单
//    //http://193.112.204.220:6005/api/user/releaseOrder
//    public static String releaseOrder() {
//        return prePathUser + "releaseOrder";
//    }
//
//    //图片上传
//    //http://193.112.204.220:6005/api/dtmanna/upImg
//    public static String upImg() {
//        return prePathUser + "upImg";
//    }
//
//    //社区推荐
//    //http://193.112.204.220:6006/api/dtmanna/tuijiancomg?pagesize=10&pageNo=1
//    //http://193.112.204.220:6006/api/dtmanna/tuijiancomg?PageSize=1&PageNo=1
//    public static String tuijiancomg() {
//        return prePathUser6006 + "tuijiancomg";
//    }
//
//    //社区其他推荐
//    //http://193.112.204.220:6006/api/dtmanna/othersList?PageSize=’当页显示条数’&PageNo=’当前页’
//    //http://193.112.204.220:6006/api/dtmanna/othersList?PageSize=1&PageNo=1
//    public static String othersList() {
//        return prePathUser6006 + "othersList";
//    }
//    //社区其它列表 （生活  ，科技 ，美食 ，科学
//    ///api/dtmanna/secondlist
//    public static String secondlist() {
//        return prePathUser6006 + "secondlist";
//    }
//
//    //.用户社区查询轮播图
//    //getTabBanner
//    public static String getTabBanner() {
//        return prePathUser6006 + "getTabBanner";
//    }
//    //创建话题（大）
//    //http://193.112.204.220:6006/api/dtmanna/CTopic
//    public static String CTopic() {
//        return prePathUser6006 + "CTopic";
//    }
//
//    //小话题评论列表
//    //http://193.112.204.220:6005/api/user/getDiscussComment?discussId=2&pageIndex=1&pageSize=10
//    public static String getDiscussComment() {
//        return prePathUser + "getDiscussComment";
//    }
//    //小话题收藏
//    //http://193.112.204.220:6005/api/user/getShoucang
//    public static String getShoucang() {
//        return prePathUser + "getShoucang";
//    }
//
//    /**
//     * userId：1//当前登录人的ID
//     * disID：1//小话题ID
//     * comment：’哎呦不错呦’  //评论内容
//     * imgUrl：图片地址  用逗号隔开
//     *
//     * @return
//     */
//    //小话题下的评论（小话题下）
//    //http://193.112.204.220:6005/api/User/ saveDisComm
//    public static String saveDisComm() {
//        return prePathUser + "saveDisComm";
//    }
//
//    /**
//     * userId:1 //用户ID
//     * targetId：2 //回复目标人id
//     * disComId：2 //评论ID
//     * replayComment：‘哎呦不错呦’
//     * replay_Type:0 //回复类型 0：回复评论 1：回复用户 2：追加评论
//     * replayParentId: 2 //父级回复ID
//     * disId：1 //小话题Id
//     */
//    //小话题下的回复（小话题下）
//    //http://193.112.204.220:6005/api/User/saveDisReplay
//    public static String saveDisReplay() {
//        return prePathUser + "saveDisReplay";
//    }
//
//    /**
//     * userId：1, //用户ID
//     * comId:’1’,  //评论或者回复ID
//     * comType:12, //  0评论  1回复
//     * isDele:0, //0：取消点赞  1:点赞
//     * disId：1  //小话题ID
//     *
//     * @return
//     */
//    //点赞或者取消点赞（小话题下）
//    //http://193.112.204.220:6005/api/User/ getLike
//    public static String getLike() {
//        return prePathUser + "getLike";
//    }
//
//
//    //忘记密码
//    //http://193.112.204.220:6005/api/user/forgetPassword
//    public static String forgetPassword() {
//        return prePathUser + "forgetPassword";
//    }
//
//
//    //获取地区code
//    //http://193.112.204.220:6005/api/user/getCityCode
//    public static String getCityCode() {
//        return prePathUser + "getCityCode";
//    }
//
//    //2 二级服务列表
//    //http://193.112.204.220:6005/api/user/getSecondServiceType
//    public static String getSecondServiceType() {
//        return prePathUser + "getSecondServiceType";
//    }
//
//    //  服务订单详情 三级服务列表
//    //http://193.112.204.220:6005/api/user/getRepairList
//    public static String getRepairList() {
//        return prePathUser + "getRepairList";
//    }
//
//    //根据商品Id和code查询
//    //http://193.112.204.220:6005/api/user/getCityPrice
//    public static String getCityPrice() {
//        return prePathUser + "getCityPrice";
//    }
//
//    // 填写订单
//    //http://193.112.204.220:6005/api/user/payOrderDetails
//    public static String payOrderDetails() {
//        return prePathUser + "payOrderDetails";
//    }
//
//    //用户端查询可用的优惠券
//    //http://193.112.204.220:6007/api/Engineer/getUserMyCoupon
//    public static String getUserMyCoupon() {
//        return prePathUser6007 + "getUserMyCoupon";
//    }
//
//    // 用户端更改订单的优惠券
//    //http://193.112.204.220:6005/api/user/updaUserOrderCoupon
//    public static String updaUserOrderCoupon() {
//        return prePathUser + "updaUserOrderCoupon";
//    }
//
//    // 工程师段更改订单的优惠券
//    //http://193.112.204.220:6005/api/User/getRepairServiceList?pageIndex=1&pageSize=10&comment=&status=1&userId=1
//    public static String getRepairServiceList() {
//        return prePathUser + "getRepairServiceList";
//    }
//
//    // 工程师查看订单详情 订单结算
//    //http://193.112.204.220:6007/api/Engineer/getEngOrder
//    public static String getEngOrder() {
//        return prePath_6007_Enginner + "getEngOrder";
//    }
//    //78.项目工程余额扣款
//    //http://211.149.216.60:6006/dtmanna/getBalance
//    public static String getBalance() {
//        return prePathUser6006 + "getBalance";
//    }
//    /**
//     * pageIndex:1//页数
//     * engineerId:1//工程师ID  当前登录工程师ID  如果查询服务 则为0，查询预约就传当前工程师ID
//     * pageSize:2//一页显示条数
//     *
//     * @return
//     */
//    //查询工程师预约订单跟服务订单
//    //http://193.112.204.220:6007/api/Engineer/getUserServiceOrder
//    public static String getUserServiceOrder() {
//        return prePath_6007_Enginner + "getUserServiceOrder";
//    }
//    /**
//     * serviceId:1//订单ID
//     * status：0//修改订单状态  订单状态  0：待付款  1：等待接单/未接单  2：等待服务/已接单  3.已出发   4.维修中  5.维修完成/订单完成
//     *
//     * @return
//     */
////    //操作订单情况
////    //http://193.112.204.220:6007/api/Engineer/updateServiceStatus
////    public static String updateServiceStatus() {
////        return prePath_6007_Enginner + "updateServiceStatus";
////    }
//
//    //.查询工程师，用户端的系统未读消息
//    //http://193.112.204.220:6005/api/user/getUnOnServiceCount
//    public static String getUnOnServiceCount() {
//        return prePathUser + "getUnOnServiceCount";
//    }
//
//    //.用户端商家端工程师端查询系统消息详情
//    //http://193.112.204.220:6005/api/user/updaSysUnread
//    public static String updaSysUnread() {
//        return prePathUser + "updaSysUnread";
//    }
//
//    //查询用户端，商家端，工程师端的系统消息（最新时间排在最上）
//    //http://193.112.204.220:6005/api/user/getSystemList
//    public static String getSystemList() {
//        return prePathUser + "getSystemList";
//    }
//
//
//    //清除 工程师，商家，用户 未读消息
//    //http://193.112.204.220:6005/api/user/deleteMessage
//    public static String deleteMessage() {
//        return prePathUser + "deleteMessage";
//    }
//
//    //查询用户端，工程师的客服聊天列表
//    //http://193.112.204.220:6006/api/dtmanna/ReadChatList
//    public static String ReadChatList() {
//        return prePathUser6006 + "ReadChatList";
//    }
//
//    //25跟App客服聊天记录
//    //http://193.112.204.220:6005/api/user/getSysCustomer
//    public static String getSysCustomer() {
//        return prePathUser + "getSysCustomer";
//    }
//
//
//    //服务订单查询当前订单抢单的工程师
//    //http://193.112.204.220:6007api/Engineer/getBillByEngineer
//    public static String getBillByEngineer() {
//        return prePathEngineer + "getBillByEngineer";
//    }
//
//    //选择工程师
//    //http://193.112.204.220:6007/api/Engineer/getBillEng?engineerId=1&orderNumber=ed5a96bcf32d4818ada95bb65c7ee643
//    public static String getBillEng() {
//        return prePathEngineer + "getBillEng";
//    }
//
//    //查询用户端社区分类
//    //http://193.112.204.220:6006/api/dtmanna/getDiscussType
//    public static String getDiscussType() {
//        return prePathUser6006 + "getDiscussType";
//    }
//
//    //社区发布话题
//    //http://193.112.204.220:6006/api/dtmanna/Communityma
//    public static String Communityma()
//    {
//        return prePathUser6006 + "Communityma";
//    }
//
//    //http://193.112.204.220:6005/api/user/saveProductComment
//    public static String saveProductComment() {
//        return prePathUser + "saveProductComment";
//    }
//
//    //用户端店铺评分保存
//    //http://193.112.204.220:6005/api/user/saveBussinessComment
//    public static String saveBussinessComment() {
//        return prePathUser + "saveBussinessComment";
//    }
//
//    //32 用户端工程师服务，预约评价
//    //http://193.112.204.220:6005/api/User/saveEngineerComment
//    public static String saveEngineerComment() {
//        return prePathUser + "saveEngineerComment";
//    }
//    //31用户申请服务订单退款
//    //api/user/saveUserServiceRefund
//    public static String saveUserServiceRefund() {
//        return prePathUser + "saveUserServiceRefund";
//    }
//
//    //消息记录
//    //http://193.112.204.220:6006/api/dtmanna/ReadChat
//    public static String ReadChat() {
//        return prePathUser6006 + "ReadChat";
//    }
//
//    // add
//    //http://193.112.204.220:6006/api/dtmanna/ADDChat
//    public static String ADDChat()
//    {
//        return prePathUser6006 + "ADDChat";
//    }
//
//    //用户充值
//    //http://211.149.216.60:6005/api/user/UserRecharge?userId=2&money=10
//    public static String UserRecharge() {
//        return prePathUser + "UserRecharge";
//    }
//
//    //用户提现
//    //http://211.149.216.60:6005/api/user/UserGetCash?userId=2&money=10
//    public static String UserGetCash() {
//        return prePathUser + "UserGetCash";
//    }
//
//    //商品订单详情
//    //http://211.149.216.60:6006/api/dtmanna/Orderdetails?OrderNum=58B340156DD5&stype=0
//    public static String Orderdetails() {
//        return prePathUser6006 + "Orderdetails";
//    }
//
//    //用户端申请退款
//    //http://211.149.216.60:6006/api/dtmanna/applyRefunds
//    public static String applyRefunds() {
//        return prePathUser6006 + "applyRefunds";
//    }
//
//
//    //http://193.112.204.220:6007/api/Engineer/getEditionNo?type=0
//    public static String getEditionNo() {
//        return prePathUser6007 + "getEditionNo";
//    }
//
//    //43工程师，用户查询所有项目工程
//    //http://193.112.204.220:6007/api/Engineer/getProjectList?Id=1&IdType=1&pageIndex=1&pageSize=10
//    public static String getProjectList() {
//        return prePath_6007_Enginner + "getProjectList";
//    }
//    //44查询项目工程详情
//    //http://193.112.204.220:6007/api/Engineer/getProjectInfo
//    public static String getProjectInfo() {
//        return prePath_6007_Enginner + "getProjectInfo";
//    }
//    //42工程师，用户发布项目工程
//    //http://193.112.204.220:6007/api/Engineer/saveProject
//    public static String saveProject() {
//        return prePath_6007_Enginner + "saveProject";
//    }
//
//    //商品详情
//    //http://193.112.204.220:6006/api/dtmanna/prodetails?PID=81&Usid=6
//    public static String prodetails() {
//        return prePathUser6006 + "prodetails";
//    }
//
//
//    //savsOrderState
//    //http://193.112.204.220:6006/api/dtmanna/savsOrderState
//    public static String savsOrderState() {
//        return prePathUser6006 + "savsOrderState";
//    }
//    //操作订单情况
//    //http://193.112.204.220:6007/api/Engineer/updateServiceStatus
//    public static String updateServiceStatus() {
//        return prePath_6007_Enginner + "updateServiceStatus";
//    }
//
//    //http://211.149.216.60:6006/api/dtmanna/deleteUnRead?Id=22&IdType=1&readId=67&readType=2
//    public static String deleteUnRead()
//    {
//        return prePathUser6006 + "deleteUnRead";
//    }
//
//    //  http://211.149.216.60:6005/api/Order/PostOrderInfo
//    public static String PostOrderInfo()
//    {
//        return al_url +":6005/api/Order/"+"PostOrderInfo";
//    }
//
//
//    //http://211.149.216.60:6005/api/Order/PostOrderInfoWxPay
//    public static String PostOrderInfoWxPay()
//    {
//        return al_url +":6005/api/Order/"+"PostOrderInfoWxPay";
//    }
//
//
//
//    ////http://193.112.204.220:6006/api/dtmanna/getDictionaryInfo?codeStr=YHDGYWM
//    public static String getDictionaryInfo()
//    {
//        return prePathUser6006 + "getDictionaryInfo";
//    }

}
