package com.espressif.iot.esptouch.demo_activity;

public interface UrlModelImp {
    void showSuccess(String result, int type);
    void showError(String msg);
}
