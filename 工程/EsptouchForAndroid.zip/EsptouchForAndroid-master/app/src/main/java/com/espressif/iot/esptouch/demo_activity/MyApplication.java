package com.espressif.iot.esptouch.demo_activity;

import android.app.Application;

public class MyApplication extends Application {


    public String httpString ;
    public String duankouString ;

    //单例模式
    private static MyApplication singleInstance;

    public static MyApplication getInstance(){
        return singleInstance;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        singleInstance = this;
        httpString = "211.149.129.205";
        duankouString = "6868";

        Url ="http://"+httpString +":"+duankouString ;
    }

    public  String Url  ;

    public String getDuankouString() {

        return duankouString;
    }

    public void setDuankouString(String duankouString) {
        this.duankouString = duankouString;
        setUrl("http://"+httpString +":"+duankouString);
    }

    public String getHttpString() {
        return httpString;
    }

    public void setHttpString(String httpString) {
        this.httpString = httpString;
        setUrl("http://"+httpString +":"+duankouString);
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }
}
