package com.espressif.iot.esptouch.demo_activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import java.util.Map;

//import com.google.gson.Gson;
//import com.google.gson.reflect.TypeToken;

public class SharedPreferencesUtil {
	private Context context;


	public static SharedPreferencesUtil sharedPreferencesUtil ;

	public static SharedPreferencesUtil getInstall(Context context){
		if (sharedPreferencesUtil==null){
			sharedPreferencesUtil = new SharedPreferencesUtil(context);
		}
		return sharedPreferencesUtil;
	}


	public SharedPreferencesUtil(Context context) {
		super();
		this.context = context;
	}
	/**
	 * 清除共享数据
	 * 
	 * @param fileName
	 */

	public void deleteShared(String fileName) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				fileName, Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.clear();
		editor.commit();
	}


	/**
	 * 清除某个key对应的值
	 * 
	 * @param fileName
	 * @param key
	 */
	public void deleteSharedKey(String fileName, String key) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				fileName, Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.remove(key);
		editor.commit();
	}

	/**
	 * 存String值
	 * 
	 * @param fileName
	 * @param key
	 * @param value
	 */
	public void putString(String fileName, String key, String value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(fileName, Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.putString(key, value);
		editor.commit();
	}

	/**
	 * 取String值
	 * 
	 * @param fileName
	 * @param key
	 * @param value
	 *            不存在时返回此值
	 * @return
	 */

	public String getString(String fileName, String key, String value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				fileName, Context.MODE_PRIVATE);
		return sharedPreferences.getString(key, value);

	}

	/**
	 * 存boolean值
	 * 
	 * @param fileName
	 * @param key
	 * @param value
	 */
	public void putBoolean(String fileName, String key, boolean value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				fileName, Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.putBoolean(key, value);
		editor.commit();
	}

	/**
	 * 取boolean值
	 * 
	 * @param fileName
	 * @param key
	 * @param value
	 *            不存在时返回此值
	 * @return
	 */
	public boolean getBoolean(String fileName, String key, boolean value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				fileName, Context.MODE_PRIVATE);
		return sharedPreferences.getBoolean(key, value);

	}


	public void putFloat(String fileName, String key, float value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(fileName, Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.putFloat(key, value);
		editor.commit();
	}
	public Float getFloat(String fileName, String key, float value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				fileName, Context.MODE_PRIVATE);
		return sharedPreferences.getFloat(key, value);

	}

	/**
	 * 存信息
	 * 
	 * @param fileName
	 * @param map
	 * @return
	 */
	public boolean saveSharedPreference(String fileName, Map<String, Object> map) {
		boolean falg = false;
		SharedPreferences preferences = context.getSharedPreferences(fileName,
				Context.MODE_PRIVATE);
		Editor editor = preferences.edit();

		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String key = entry.getKey();
			Object object = entry.getValue();
			if (object instanceof Boolean) {
				Boolean new_name = (Boolean) object;
				editor.putBoolean(key, new_name);
			} else if (object instanceof Integer) {
				Integer new_name = (Integer) object;
				editor.putInt(key, new_name);
			} else if (object instanceof Float) {
				Float new_name = (Float) object;
				editor.putFloat(key, new_name);
			} else if (object instanceof Long) {
				Long new_name = (Long) object;
				editor.putLong(key, new_name);
			} else if (object instanceof String) {
				String new_name = (String) object;
				editor.putString(key, new_name);
			}
		}
		falg = editor.commit();
		return falg;
	}

	/**
	 * 取信息
	 * 
	 * @param fileName
	 * @return map
	 */
	public Map<String, ?> readSharedPreference(String fileName) {
		SharedPreferences preferences = context.getSharedPreferences(fileName,
				Context.MODE_PRIVATE);
		Map<String, ?> map = preferences.getAll();
		return map;
	}
	/**
	 * 存int值
	 *
	 * @param fileName
	 * @param key
	 * @param value
	 */
	public void putInt(String fileName, String key, Integer value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				fileName, Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.putInt(key, value);
		editor.commit();
	}

	/**
	 * 取int值
	 *
	 * @param fileName
	 * @param key
	 * @param value
	 *            不存在时返回此值
	 * @return
	 */
	public Integer getInt(String fileName, String key, Integer value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				fileName, Context.MODE_PRIVATE);
		return sharedPreferences.getInt(key, value);

	}
//	public void putListString(String fileName, String key, List<String> list) {
//		SharedPreferences sharedPreferences = context.getSharedPreferences(fileName, Context.MODE_PRIVATE);
//		Editor editor = sharedPreferences.edit();
//
//		if (null == list || list.size() <= 0)
//			return;
//		Gson gson = new Gson();
//		//转换成json数据，再保存
//		String strJson = gson.toJson(list);
//		editor.clear();
//		editor.putString(key, strJson);
//		editor.commit();
//	}
//
//	public <T> List<T> getListString(String fileName, String key, List<String> list) {
//		SharedPreferences sharedPreferences = context.getSharedPreferences(fileName, Context.MODE_PRIVATE);
//		Editor editor = sharedPreferences.edit();
//		List<T> datalist=new ArrayList<>();
//		String strJson = sharedPreferences.getString(key, null);
//		if (null == strJson) {
//			return datalist;
//		}
//		Gson gson = new Gson();
//		datalist = gson.fromJson(strJson, new TypeToken<List<T>>() {
//		}.getType());
//		return datalist;
//
//	}

}
