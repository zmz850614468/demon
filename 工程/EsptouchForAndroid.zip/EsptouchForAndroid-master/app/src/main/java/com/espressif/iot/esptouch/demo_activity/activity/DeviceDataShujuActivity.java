package com.espressif.iot.esptouch.demo_activity.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.espressif.iot.esptouch.demo_activity.BaseActivity;
import com.espressif.iot.esptouch.demo_activity.MyApplication;
import com.espressif.iot.esptouch.demo_activity.NetUtil;
import com.espressif.iot_esptouch_demo.R;

import java.util.HashMap;
import java.util.Map;

public class DeviceDataShujuActivity extends BaseActivity {


    EditText e1 ,e2, e3, e4 ,e5 ;
    Button b1 ,b2 ,b3;
    TextView t1 ,t2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_data_shuju);

        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        e3 = findViewById(R.id.e3);
        e4 = findViewById(R.id.e4);
        e5 = findViewById(R.id.e5);

        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("type", e3.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/queryDeviceValue", map, 1);

                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/queryDeviceValue"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"type="+"" + e3.getText().toString());

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("scene", e4.getText().toString());
                map.put("type", e3.getText().toString());
                map.put("flag", e5.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/queryDeviceValue", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/queryDeviceValue"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"scene="+"" + e4.getText().toString()
                        +"\n"+"type="+"" + e3.getText().toString()
                        +"\n"+"flag="+"" + e5.getText().toString());


            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t1.setText("");
                t2.setText("");
            }
        });
    }


    @Override
    public void showSuccess(String result, int type) {
        super.showSuccess(result, type);
        if (type == 1){
            t2.setText(result+"");
        }
    }
}
