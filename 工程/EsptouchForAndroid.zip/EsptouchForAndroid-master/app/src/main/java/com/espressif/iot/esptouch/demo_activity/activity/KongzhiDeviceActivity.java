package com.espressif.iot.esptouch.demo_activity.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.espressif.iot.esptouch.demo_activity.BaseActivity;
import com.espressif.iot.esptouch.demo_activity.MyApplication;
import com.espressif.iot.esptouch.demo_activity.NetUtil;
import com.espressif.iot_esptouch_demo.R;
import com.espressif.iot_esptouch_demo.R;
import java.util.HashMap;
import java.util.Map;

public class KongzhiDeviceActivity extends BaseActivity {

    EditText e1 ,e2, e3, e4 ,e5 ,e6;

    TextView t1 ,t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kongzhi_device);


        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        e3 = findViewById(R.id.e3);
        e4 = findViewById(R.id.e4);
        e5 = findViewById(R.id.e5);
        e6 = findViewById(R.id.e6);


        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);

        findViewById(R.id.btn_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("cmd", e3.getText().toString());
                map.put("type", e4.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"cmd="+"" + e3.getText().toString()
                        +"\n"+"type="+"" + e4.getText().toString());
            }
        });

        findViewById(R.id.btn_2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("cmd", e3.getText().toString());
                map.put("scene", e5.getText().toString());
                map.put("type", e4.getText().toString());
                map.put("flag", e6.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"cmd="+"" + e3.getText().toString()
                        +"\n"+"scene="+"" + e5.getText().toString()
                        +"\n"+"type="+"" + e4.getText().toString()
                        +"\n"+"flag="+"" + e6.getText().toString()
                );
            }
        });

        findViewById(R.id.btn_3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("type", e4.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"type="+"" + e4.getText().toString()
                      );
            }
        });

        findViewById(R.id.btn_4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("type", e4.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"type="+"" + e4.getText().toString()
                );
            }
        });

        findViewById(R.id.btn_5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("type", e4.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl()+ "/api/revdata/controlDevice", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"type="+"" + e4.getText().toString());
            }
        });
        findViewById(R.id.btn_6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("type", e4.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"type="+"" + e4.getText().toString());
            }
        });
        findViewById(R.id.btn_7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("type", e4.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"type="+"" + e4.getText().toString());
            }
        });
        findViewById(R.id.btn_8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> map = new HashMap<>();
                map.put("op", e1.getText().toString());
                map.put("deviceid", e2.getText().toString());
                map.put("type", e4.getText().toString());
                HttpPost(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice", map, 1);
                t1.setText(MyApplication.getInstance().getUrl() + "/api/revdata/controlDevice"
                        +"\n"+"op="+"" + e1.getText().toString()
                        +"\n"+"deviceid="+"" + e2.getText().toString()
                        +"\n"+"type="+"" + e4.getText().toString());
            }
        });

        findViewById(R.id.btn_9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText("");
                t2.setText("");
            }
        });

    }


    @Override
    public void showSuccess(String result, int type) {
        super.showSuccess(result, type);
        t2.setText(result);
    }
}
