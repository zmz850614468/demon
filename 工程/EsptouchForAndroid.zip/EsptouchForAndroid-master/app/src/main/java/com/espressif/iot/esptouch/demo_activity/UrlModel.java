package com.espressif.iot.esptouch.demo_activity;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class UrlModel {

    private Handler handler;
    private Context mContext ;
    private static UrlModel urlModel;

    public UrlModel(Context mContext){
        this.mContext = mContext ;
        handler = new Handler(Looper.getMainLooper());
    }

    public static UrlModel getInstance(Context context) {
        if (urlModel == null) {
            synchronized (UrlModel.class) {
                if (urlModel == null) {
                    urlModel = new UrlModel(context);
                }
            }
        }
        return urlModel;
    }

    public void HttpGet(String url, final int type , final UrlModelImp callBack){
        Log.i("info", "get="+url);
        OkHttpUtils.getInstance(mContext).asyncGet(url, new OkHttpUtils.HttpCallBack() {
            @Override
            public void onError(Request request, final IOException e) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        error(mContext,e,callBack);
                    }
                });
            }
            @Override
            public void onSuccess(Request request, final String result) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        callBack.showSuccess(result,type);
                    }
                });
            }
        });
    }
    public void HttpPost(String url, final Map<String, String> maps, final int type , final UrlModelImp callBack){
        Log.i("info", "post="+url);
        String content = "";
        FormBody.Builder params = new FormBody.Builder();
        HashMap<Integer, Integer> map = (HashMap)maps;
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            params.add(entry.getKey()+"", entry.getValue()+"");
            content += "&"+entry.getKey()+"="+entry.getValue();
        }
        Log.i("info", content);
        Log.i("yoyo", "HttpPost: "+params.toString());
        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .post(params.build())
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onResponse(Call arg0, Response response) throws IOException {
                final String result = response.body().string();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        callBack.showSuccess(result,type);
                    }
                });
            }
            @Override
            public void onFailure(Call arg0, final IOException arg1) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        error(mContext,arg1,callBack);
                    }
                });
            }
        });

    }

    public void error(Context mContext , IOException e, UrlModelImp callBack){
        if (e instanceof SocketTimeoutException) {
//            Toast.makeText(mContext, "网络中断，请检查您的网络状态", Toast.LENGTH_SHORT).show();
        } else if (e instanceof ConnectException) {
//            Toast.makeText(mContext, "网络中断，请检查您的网络状态", Toast.LENGTH_SHORT).show();
        } else {
//            LogUtil.e(e.getMessage());
        }
//        Toast.makeText(mContext, e.getMessage(), Toast.LENGTH_SHORT).show();
        callBack.showError("onFailure="+e.getMessage());
    }


}



