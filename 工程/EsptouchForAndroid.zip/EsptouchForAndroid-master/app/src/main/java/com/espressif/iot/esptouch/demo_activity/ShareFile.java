package com.espressif.iot.esptouch.demo_activity;

public class ShareFile {

	public static final String USERFILE="userInfoFile";
	public static final String UID="userid"; // 用户id
	public static final String DEVICEID="deviceid"; // 设备id
	public static final String DEVICEID2="deviceid2"; // 设备id two
	public static final String DEVICEID3="deviceid3"; // 设备id 3
}
